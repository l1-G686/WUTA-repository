#pragma once
void func(int num);

