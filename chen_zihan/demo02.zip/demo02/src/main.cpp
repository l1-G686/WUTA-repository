#include <iostream>
#include"func.h"
using namespace std;
int main(){
	func(1145);
	cout<<"successfully"<<endl;
}
