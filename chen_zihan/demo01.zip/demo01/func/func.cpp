#include<iostream>
#include"func.h"
using namespace std;
void func(int num){
	cout<<num<<endl;
}
