void tunc(int num);

