#include<iostream>
#include"func.h"
using namespace std;
int main()
{
	func(100);
	cout<<"dong tai lianjieku shiyong chenggong!"<<endl;
	return 0;
}
