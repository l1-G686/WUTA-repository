#include<iostream>
#include "func.h"
using namespace std;

void func(int data)
{
	cout<<data<<endl;
}

