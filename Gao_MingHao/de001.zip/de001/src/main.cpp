#include<iostream>
#include "func.h"

using namespace std;
int main()
{
	func(100);
	cout<<"D"<<endl;
	return 0;
}

