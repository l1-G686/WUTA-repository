#include<iostream>
#include"func.h"
using namespace std;
int main(){
	func(100);
	cout<<"tilu"<<endl;
	return 0;
}
