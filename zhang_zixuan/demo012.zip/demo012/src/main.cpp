#include<iostream>
#include"func.h"
using namespace std;
int main(){

	func(100);
	cout<<"dong tai lian jie ku"<<endl;

	return 0;}
