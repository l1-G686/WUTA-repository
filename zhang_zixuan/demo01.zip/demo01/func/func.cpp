#include "func.h"
#include<iostream>
using namespace std;
void func(int data){
cout<<data<<endl;

}
