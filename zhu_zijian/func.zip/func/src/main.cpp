#include<iostream>
#include"func.h"
using namespace std;
int main()
{ func(10);
  cout<<"lian jie dong tai ku cheng gong"<<endl;
  return 0;
}
