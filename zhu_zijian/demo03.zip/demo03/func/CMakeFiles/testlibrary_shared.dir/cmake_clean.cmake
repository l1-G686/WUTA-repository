file(REMOVE_RECURSE
  "../lib/libtestFunc.pdb"
  "../lib/libtestFunc.so"
  "CMakeFiles/testlibrary_shared.dir/func.cpp.o"
  "CMakeFiles/testlibrary_shared.dir/func.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/testlibrary_shared.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
