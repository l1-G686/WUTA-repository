# Empty dependencies file for testlibrary_shared.
# This may be replaced when dependencies are built.
