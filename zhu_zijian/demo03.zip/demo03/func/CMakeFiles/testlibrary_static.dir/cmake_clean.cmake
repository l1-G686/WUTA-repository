file(REMOVE_RECURSE
  "../lib/libtestFunc.a"
  "../lib/libtestFunc.pdb"
  "CMakeFiles/testlibrary_static.dir/func.cpp.o"
  "CMakeFiles/testlibrary_static.dir/func.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/testlibrary_static.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
