# Empty dependencies file for testlibrary_static.
# This may be replaced when dependencies are built.
