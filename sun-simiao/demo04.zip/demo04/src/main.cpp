#include<iostream>
#include"func.h"
using namespace std;
int main()
{

func(100);
cout<<"ok"<<endl;


	return 0;
}
