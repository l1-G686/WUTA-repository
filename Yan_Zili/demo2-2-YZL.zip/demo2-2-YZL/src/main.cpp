#include<iostream>
#include"func.h"
using namespace std;

int main(){
	func (100);
	cout<<"WUTA无人组培训第二次作业——动态链接库——严梓栗"<<endl;
	return 0;
}
