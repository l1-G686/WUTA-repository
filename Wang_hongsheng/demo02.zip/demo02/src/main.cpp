#include <iostream>
#include "func.h"
using namespace std;

int main()
{
	func(100);
	cout <<"动态连接库使用成功!"<<endl;
	return 0;
}
